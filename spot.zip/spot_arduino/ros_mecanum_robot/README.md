# ros_mecanum_robot
Arduino code to control a robot with mecanum wheels via ROS Twist messages using a NodeMcu or ESP8266 and a PCA 9685 servo controller

#robocar it has four wheels in yellow, black rubber tires and it dirves. You wouldn't believe how it drives. It drives sideways. Have you ever seen such a thing? Ok, unless you are a robo researcher your mind would be more than blown. God bless!  Thank you and goog night. Stay save! Jeff Bezos is lurking! Schnitzel
